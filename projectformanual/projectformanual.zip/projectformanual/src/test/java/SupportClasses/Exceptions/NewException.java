package SupportClasses.Exceptions;

public class NewException extends Exception {
    public NewException(String message){
        super(message);
    }
}
