package SupportClasses.Exceptions;

public class NewAssertError extends AssertionError {
    public NewAssertError(String message){
        super(message);
    }
}
